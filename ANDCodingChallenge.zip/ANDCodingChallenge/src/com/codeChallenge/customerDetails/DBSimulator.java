package com.codeChallenge.customerDetails;

import java.util.HashMap;
import java.util.Map;

/*
 * DataBase
 */
public class DBSimulator {
	 
	protected Map<String,String>  customerDB = new HashMap<String, String>();
	
	DBSimulator ()
	{	
		//Key is unique CustomerId,Values are ; separated Telephone numbers
		customerDB.put("0001","0123456789;0123456781;0123456711");
		customerDB.put("0002","0223456789;0123456782" );
		customerDB.put("0003","0323456789;0123456783" );
		customerDB.put("0004","0423456789;0123456784" );
		customerDB.put("0005","0523456789;0123456785" );
		customerDB.put("0006","0623456789" );
		customerDB.put("0007","0723456789;0123456787" );
		customerDB.put("0008","0823456789;0123456788" );
		customerDB.put("0009","0923456789;0123456789" );
		
	}

}
