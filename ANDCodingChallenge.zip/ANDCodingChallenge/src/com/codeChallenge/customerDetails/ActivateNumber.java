package com.codeChallenge.customerDetails;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ActivateNumber {
	
	private String customerId;
    private String phoneNumber;
 
    public String getCustomerId() {
        return customerId;
    }
 
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
 
    public String getPhoneNumber() {
        return phoneNumber;
    }
 
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
 
    public ActivateNumber(String customerId, String phoneNumber) {
        super();
        this.customerId = customerId;
        this.phoneNumber = phoneNumber;
    }
    
    public ActivateNumber() {
    	
    }


}
