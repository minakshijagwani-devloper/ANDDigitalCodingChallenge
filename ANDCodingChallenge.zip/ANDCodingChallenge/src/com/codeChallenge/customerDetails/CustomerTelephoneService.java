package com.codeChallenge.customerDetails;


import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.codeChallenge.customerDetails.DBSimulator;

@Path("/Details")
public class CustomerTelephoneService   {
	String customerId ;
	
	/*
	 * API Method for fetching all customer Telephone Numbers.
	 */
    @GET
    @Path("/getAllPhoneNumber")
    @Produces(MediaType.APPLICATION_XML)
    public ListOfTelephoneNumbers getAllPhoneNumber() {
    	DBSimulator listOfPhoneNumbers = new DBSimulator();
    	ListOfTelephoneNumbers listAllTelephoneNumbers = new ListOfTelephoneNumbers();
        List<String> listPerson = new ArrayList<String>();
        listOfPhoneNumbers.customerDB.forEach((k,v) -> 
        {
        	int countPhoneNumbers =0;
        	countPhoneNumbers = v.split(";").length;
        	while(countPhoneNumbers>0)
        	{
        		listPerson.add(v.split(";")[countPhoneNumbers-1]);
        		countPhoneNumbers--;
        	}
        });
        System.out.println("List of Phone Numbers"+listPerson);
        listAllTelephoneNumbers.setTelephoneNumber(listPerson);
        return listAllTelephoneNumbers;
    }
    
    /*
	 * API Method for fetching Telephone Numbers for particular customer.
	 */
    @GET
    @Path("/getCustomerPhoneNumber")
    @Produces(MediaType.APPLICATION_XML)
    public ListOfTelephoneNumbers getCustomerPhoneNumber(@QueryParam("customerId")
    @DefaultValue("") String customerId) {
    	DBSimulator listOfPhoneNumbers = new DBSimulator();
    	
    	ListOfTelephoneNumbers listAllTelephoneNumbers = new ListOfTelephoneNumbers();
        List<String> listNumbers = new ArrayList<String>();
        if(listOfPhoneNumbers.customerDB.get(customerId) == null)
        	return listAllTelephoneNumbers;	
        System.out.println(" For Cutomer "+customerId+"  Phone Numbers : "+listOfPhoneNumbers.customerDB.get(customerId));
        int countPhoneNumbers =0;
    	countPhoneNumbers = listOfPhoneNumbers.customerDB.get(customerId).split(";").length;
    	System.out.println("Count PhoneNUmber "+countPhoneNumbers);
    	while(countPhoneNumbers>0)
    	{
    		listNumbers.add(listOfPhoneNumbers.customerDB.get(customerId).split(";")[countPhoneNumbers-1]);
    		countPhoneNumbers--;
    	}
    	listAllTelephoneNumbers.setTelephoneNumber(listNumbers);
        
        return listAllTelephoneNumbers;
    }
    
    /*
	 * API Method for fetching all customer Telephone Numbers.
	 */
    @PUT
    @Path("/activateNumber")
    @Produces(MediaType.APPLICATION_XML)
    public ActivateNumber activateNumber(@QueryParam("phoneNumber")
    @DefaultValue("") String phoneNumber) {
    	DBSimulator listOfPhoneNumbers = new DBSimulator();
    	ActivateNumber activatedNumber = new ActivateNumber();
    	listOfPhoneNumbers.customerDB.forEach((k,v) ->{
    		if(v.contains(phoneNumber)) 
    		{
    			customerId=k;
    			
    		}
    	 });
       
        if(customerId == null)
        	return activatedNumber;	
        System.out.println(" For Cutomer "+customerId+"  Phone Numbers : "+listOfPhoneNumbers.customerDB.get(customerId));
        activatedNumber.setCustomerId(customerId);
        activatedNumber.setPhoneNumber(phoneNumber);
        return activatedNumber;
    }  
}
