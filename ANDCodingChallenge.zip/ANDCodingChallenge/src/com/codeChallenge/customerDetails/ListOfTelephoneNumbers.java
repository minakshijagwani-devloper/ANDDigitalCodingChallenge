package com.codeChallenge.customerDetails;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ListOfTelephoneNumbers {
	
	private List<String> telephoneNumbers;
	
	public void setTelephoneNumber(List<String> telephoneNumbers)
	{
		this.telephoneNumbers = telephoneNumbers;
	}
	
	public List<String> getTelephoneNumber()
	{
		return this.telephoneNumbers;
	}
}
